﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace shoppingstore.Models
{
    public class Producer
    {
        public int ProducerID { get; set; }
        public string Name { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace shoppingstore.Models
{
    [Bind(Exclude = "ItemID")]
    public class Item
    {
        [ScaffoldColumn(false)]
        public int ItemID { get; set; }
        [DisplayName("Category")]
        public int CategoryID { get; set; }
        [DisplayName("Producer")]
        public int ProducerID { get; set; }
        [Required(ErrorMessage ="An Item Title is Required")]
        [StringLength(160)]
        public string Title { get; set; }
        [Required(ErrorMessage = "An Item Price is Required")]
        [Range(0.1,100,ErrorMessage ="Price should be between 0.1 and 100")]
        public decimal Price { get; set; }
        [DisplayName("Item Art URL")]
        [StringLength(1024)]
        public string ItemArtURL { get; set; }
        public virtual Category Category { get; set; }
        public virtual Producer Producer { get; set; }
        public virtual List<OrderDetail> OrderDetail { get; set; }
    }
}
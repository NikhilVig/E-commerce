﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace shoppingstore.Models
{
    public class ShoppingStoreEntities:DbContext
    {
        public ShoppingStoreEntities() : base("DefaultConnection")
        {

        }

        
        public DbSet<Item> Item { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<Producer> Producers { get; set; }
        public DbSet<Cart> Cart { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<OrderDetail> OrderDetail { get; set; }

        public System.Data.Entity.DbSet<shoppingstore.ViewModels.ShoppingCartViewModel> ShoppingCartViewModels { get; set; }
    }

}